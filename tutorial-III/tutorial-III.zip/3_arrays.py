import numpy as np

#numbers:
x=10.5
y=20.5

#arrays of numbers
arrayA=np.array([10,13,11,20])
arrayB=np.array([20,11,-14,-15])

print(arrayA)
print(arrayB)
#TODO
#1: recap indexing (print with for loop, add element-by-element with for loop)
#1: operations of array with numbers
#2: vector operations - element by element
#3: sum, mean, abs, std
#4: simple boolean operations, show how to detect NaNs
