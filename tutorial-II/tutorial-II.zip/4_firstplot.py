import numpy as np
import matplotlib.pyplot as plt
#loading only first three columns
ts,left_x,left_y=np.loadtxt('exampleEyetrackerData.tsv',usecols=[0,1,2],unpack=True,skiprows=1)

plt.plot(left_x)
plt.show()

#TODO in class: plot each variable one at a time

#TODO in class: understand "gaps" in data; understand data quality from plot

#TODO in class: plot each variable as a function of time


